--[[

name:GG高仿XS写法
ps:支持冻结，支持范围搜索
by:XQM

]]
local app = {}
function Assert(data)   --判断
if data == nil or data == "" or data == "nil" then
return false
else
return true
end
end
function mearrass(memory, array)   --判断
if Assert(memory) and Assert(array) then
return true
else
return false
end
end
function typetab(array, type)   --把所有类型组成一个数组防不写类型
local datatype = {}
for i = 1, #array do
if Assert(array[i].type) then
table.insert(datatype, i, array[i].type)
else
if Assert(type) then
table.insert(datatype, i, type)
else
return false
end
end
end
return true, datatype
end
function app.memorysearch(memory, array, type)   --内存搜索，参数为(内存， 特征码数组， 类型(类型可空))
gg.setVisible(false)
local isok = mearrass(memory, array)
if isok then
local isok, datatype = typetab(array, type)
if isok then
if Assert(array[1].hv) then   --判断主特征码是否有hv，有即范围搜索
gg.clearResults()
gg.setRanges(memory)
gg.searchNumber(array[1].lv .. "~" .. array[1].hv, datatype[1])   --有hv进行范围搜索
else
gg.clearResults()
gg.setRanges(memory)
gg.searchNumber(array[1].lv, datatype[1])   --普通搜索
end
if gg.getResultCount() == 0 then   --判断搜索到值没
return false   --没搜到值返回false
else
local tab = {}
local data = gg.getResults(gg.getResultCount())   --保存搜索到的数据到data
gg.clearResults()
for i = 1, #data do
data[i].isok = true   --把搜索到的值，全部设置为true
end
for i = 2, #array do
local t = {}
local offset = array[i].offset
for x = 1, #data do   --遍历内存
t[#t + 1] = {}
t[#t].address = data[x].address + offset
t[#t].flags = datatype[i]
end
local t = gg.getValues(t)
for z = 1, #t do
if Assert(array[i].hv) then   --判断副特征码是否有hv参数
if tonumber(t[z].value) < tonumber(array[i].lv) or tonumber(t[z].value) > tonumber(array[i].hv) then
--↑↑↑进行范围判断
data[z].isok = false   --不符合条件的设置为false
end
else
if tostring(t[z].value) ~= tostring(array[i].lv) then   --普通判断(没有hv参数)
data[z].isok = false   --不符合设置为false
end
end
end
end
for i = 1, #data do   --重新遍历数组
if data[i].isok then   --判断是否为true(符合条件的)
tab[#tab + 1] = data[i].address   --把符合条件的地址写入数组
end
end
if #tab > 0 then   --判断地址数组是否大于0，大于0就是搜到了符合条件的值，反之没搜到
return true, tab   --搜到返回true和地址数组
else
return false   --没搜到返回false
end
end
else
print("type参数错误")   --类型错误
gg.toast("type参数错误")
os.exit()
end
else
print("memory or array参数错误")   --内存或类型错误
gg.toast("memory or array参数错误")
os.exit()
end
end
function app.memoryread(addr, type)   --读内存，参数为(地址，类型)
local t = {}
t[1] = {}
t[1].address = addr
t[1].flags = type
if #t > 0 then
return true, gg.getValues(t)[1].value   --读到返回true和读到得值
else
return false   --反之返回false
end
end
function app.memorywrite(addr, type, value, freeze)   --写内存，参数为(地址，类型，写入得值，是否冻结(可空))
local t = {}
t[1] = {}
t[1].address = addr
t[1].flags = type
t[1].value = value
if #t > 0 then
if Assert(freeze) then   --判断是否有冻结参数
t[1].freeze = freeze
--gg.setValues(t)   --这行自行选择，如果有这行，false会修改并保存到列表，如果没这行，false只会保存到列表而不会修改
return gg.addListItems(t)   --成功返回true
else
return gg.setValues(t)   --成功返回true
end
else
return false   --失败
end
end



--↓↓↓用上边的代码进行二次封装出来的指针写法
qmnb = function(daarr)
local array = {}
for i = 1, #daarr["搜索数组"] do
local data = {["lv"] = daarr["搜索数组"][i][1], ["offset"] = daarr["搜索数组"][i][2], ["type"] = daarr["搜索类型"]}
table.insert(array, i, data)
end
local isok, data = app.memorysearch(daarr["搜索内存"], array)
if isok then
for i = 1, #data do
for x = 1, #daarr["修改数组"] do
app.memorywrite(data[i] + daarr["修改数组"][x][2], daarr["搜索类型"], daarr["修改数组"][x][1])
end
end
gg.toast(daarr["功能名称"] .. "开启成功，共修改" .. #data * #daarr["修改数组"] .. "条数据")
else
gg.toast(daarr["功能名称"] .. "开启失败")
end
end
--↑↑↑



--↓↓↓实例

local memory = 131072
local array = {
{["lv"] = 7176908390479364103, ["type"] = 32},
{["lv"] = -1, ["offset"] = 0x114, ["type"] = 16},
{["lv"] = 1, ["offset"] = 0x11C, ["type"] = 16},
{["lv"] = -127, ["offset"] = 0x120, ["type"] = 16},
{["lv"] = 0.24022650719, ["offset"] = 0x124, ["type"] = 16},
{["lv"] = 0.69314718246, ["offset"] = 0x128, ["type"] = 16}
}
local isok, data = app.memorysearch(memory, array)
if isok then
for i = 1, #data do
app.memorywrite(data[i] + 8, 16, 5444)
app.memorywrite(data[i] + 0x110, 16, 130)
end
gg.toast("透视一步开启成功")
else
gg.toast("透视一步开启失败")
end

--和平675透视虚化，有675得可以用哦--↑↑↑

--↓↓↓范围搜索实例

local memory = 32
local array = {
{["lv"] = 40000, ["type"] = 16},
{["lv"] = 2, ["hv"] = 3, ["offset"] = -0x74, ["type"] = 16},
{["lv"] = 1, ["offset"] = -0x70, ["type"] = 16},
{["lv"] = 0.4, ["hv"] = 0.5, ["offset"] = -0x6C, ["type"] = 16},
{["lv"] = 0.4, ["hv"] = 0.5, ["offset"] = -0x68, ["type"] = 16},
{["lv"] = 50000, ["hv"] = 150000, ["offset"] = -0x48, ["type"] = 16}
}
local isok, data = app.memorysearch(memory, array)
if isok then
for i = 1, #data do
app.memorywrite(data[i] + -0xE0, 16, 1000000)
end
gg.toast("全枪瞬击开启成功")
else
gg.toast("全枪瞬击开启失败")
end

--   hv得意思是lv的值到hv的值的中间的任意值，，，
--比如上边的["lv"] = 0.4, ["hv"] = 0.5，，，意思是0.4到0.5之间的所有值
--这也就是所谓的范围搜索了

--国际服全枪瞬击--↑↑↑

--↓↓↓指针实例

qmnb{
["功能名称"] = "人物黄色",
["搜索内存"] = 131072,
["搜索类型"] = 4,
["搜索数组"] = {{1661304845, 0}, {1194380046, 8}},
["修改数组"] = {{6, 4}}
}

--和平675黄色

--↑↑↑



