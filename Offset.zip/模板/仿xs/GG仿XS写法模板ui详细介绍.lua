--GG仿XS写法
--1.0
--暂时不支持冻结，副特征码数量理论不限制
--反馈群：984332893
--by：LiuL丶XQM
--二改留版权，不留死全家
--配置↓↓↓勿修改
function split(szFullString, szSeparator) local nFindStartIndex = 1 local nSplitIndex = 1 local nSplitArray = {} while true do local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex) if not nFindLastIndex then nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString)) break end nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1) nFindStartIndex = nFindLastIndex + string.len(szSeparator) nSplitIndex = nSplitIndex + 1 end return nSplitArray end function xgxc(szpy, qmxg) for x = 1, #(qmxg) do xgpy = szpy + qmxg[x]["offset"] xglx = qmxg[x]["type"] xgsz = qmxg[x]["value"] gg.setValues({[1] = {address = xgpy, flags = xglx, value = xgsz}}) xgsl = xgsl + 1 end end function xqmnb(qmnb) gg.clearResults() gg.setRanges(qmnb[1]["memory"]) gg.searchNumber(qmnb[3]["value"], qmnb[3]["type"]) if gg.getResultCount() == 0 then gg.toast(qmnb[2]["name"] .. "开启失败") else gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) if gg.getResultCount() == 0 then gg.toast(qmnb[2]["name"] .. "开启失败") else sl = gg.getResults(999999) sz = gg.getResultCount() xgsl = 0 if sz > 999999 then sz = 999999 end for i = 1, sz do pdsz = true for v = 4, #(qmnb) do if pdsz == true then pysz = {} pysz[1] = {} pysz[1].address = sl[i].address + qmnb[v]["offset"] pysz[1].flags = qmnb[v]["type"] szpy = gg.getValues(pysz) pdpd = qmnb[v]["lv"] .. ";" .. szpy[1].value szpd = split(pdpd, ";") tzszpd = szpd[1] pyszpd = szpd[2] if tzszpd == pyszpd then pdjg = true pdsz = true else pdjg = false pdsz = false end end end if pdjg == true then szpy = sl[i].address xgxc(szpy, qmxg) xgjg = true end end if xgjg == true then gg.toast(qmnb[2]["name"] .. "开启成功,共修改" .. xgsl .. "条数据") else gg.toast(qmnb[2]["name"] .. "开启失败") end end end end
--配置↑↑↑勿修改，调用方法   xqmnb(qmnb)
function Main()
SN = gg.multiChoice({
"上色",
"退出脚本"
}, nil, "这里可以填写你的QQ")
if SN == nil then else
if SN[1] == true then a() end
if SN[2] == true then Exit() end
end XGCK = -1 end

--还不懂你删除吧。用原GG脚本吧
function i4x()
gg.clearResults()
gg.setRanges(gg.REGION_BAD)
gg.searchNumber("8196;8192;256;96;8200::", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.searchNumber("8200", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(10)
gg.editAll("6", gg.TYPE_DWORD)
gg.toast("人物黄色开启成功")
end



function a()
qmnb = {
{["memory"] = gg.REGION_BAD},
             -- ↑内存  范围  这个是A内存
{["name"] = "人物上色"},
            -- ↑功能名称
{["value"] = 8196, ["type"] = gg.TYPE_DWORD},
            -- ↑主特征码            ↑类型
            --主特征码要用数值 数少的
            --如果你要改的数值是1F  不能用1F
            --1F也可以不用写进副特征码里
            --如果用1F当特征码，他会用搜索1F，
            --1F有上万个数据，他会把每个1F找你写的偏移
            --如果你的GG特码是0D;1F;1F;0F;1F;2F::50，你要改这个2F。范围附近没大数值的话。那你还是用GG语法吧
            
{["lv"] = 8192, ["offset"] = 0x8, ["type"] = gg.TYPE_DWORD},
      -- ↑副特征码    ↑付特征码与主特征码的偏移
      --GG里一行是成4
      --如
      --BC420054 3F800000; 1,065,353,216D; 9.20161819458F;
      --BC420058 00000000; 0D; 0.0F;
      --9.20161819458是主特征码  下一行是偏移4  在下一行是偏移8
      --9.20161819458往上是一行是-4 上两行是-8
      --以此类推
{["lv"] = 256, ["offset"] = 0x14, ["type"] = gg.TYPE_DWORD},
{["lv"] = 96, ["offset"] = 0x68, ["type"] = gg.TYPE_DWORD},
{["lv"] = 8200, ["offset"] = 0x80, ["type"] = gg.TYPE_DWORD},
   -- ↑副特征码    ↑付特征码与主特征码的偏移
}
qmxg = {
       --修改
{["value"] = 6, ["offset"] = 0x80, ["type"] = gg.TYPE_DWORD},
        -- ↑改的值      ↑付特征码与主特征码的偏移。
        --把主特征码的偏移24的位置改成155了
}
xqmnb(qmnb)
end



function Exit()
os.exit()
end
while true do
  if gg.isVisible(true) then
    XGCK = 1
    gg.setVisible(false)
  end
  gg.clearResults()
  if XGCK == 1 then
    Main()
  end
end








