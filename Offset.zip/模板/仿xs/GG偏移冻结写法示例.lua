----[[   主要看加速和步枪聚点   ]]

function Main0()
SN = gg.choice({
	 "散弹聚点(开镜)",
	 "聚点(不开镜)",
	 "加速(站立)",
	 "防退",
	  "无后四代",
	  "无后绘制",
}, nil, "我是一个默默无闻的公告")
if SN==1 then
	 Main1()
end
if SN==2 then
	 HS5()
end
if SN==3 then
	 jiasu()
end
if SN==4 then
	fangtui()
end
if SN==5 then
	Main2()
end
if SN==6 then
	huizhi()
	end
FX = 0
end

function Main1()
SN = gg.choice({
	 "s686、 s1897聚点",
	 "S12K聚点",
}, nil, "")
if SN==1 then
	 HS2()
end
if SN==2 then
	 HS3()
end
FX = 0
end

function HS2()
	 gg.clearResults()
	 gg.setRanges(32)
	 gg.searchNumber("400.0;1.0;0.97000002861;0.94999998808;1.42850005627;1.5;1.5;4.0;1.09375;1.0;12.0;18.0;3.5::61", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
	 gg.searchNumber("1.5;1.5::5", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
	 gg.getResults(100)
	 gg.editAll("0", gg.TYPE_FLOAT)
	 gg.toast("s686、s1897聚点开启成功！")
	 gg.clearResults()
end

function HS3()
	 gg.clearResults()
	 gg.setRanges(32)
	 gg.searchNumber("300;1;1.79999995232;1.79999995232;4.0;1.09375;1.0;12.0;18.0::61", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
	 gg.searchNumber("1.79999995232;1.79999995232::5", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
	 gg.getResults(100)
	 gg.editAll("0", gg.TYPE_FLOAT)
	 gg.toast("S12K聚点开启成功！")
	 gg.clearResults()
end

function HS5()
gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("33,685,506;16,777,478;-1.0F;1;1;5.0F;176,293,393;1;0;0;0;-1::117", gg.TYPE_DWORD)
if gg.getResultCount() == 0 then
gg.toast("全步枪聚点开启失败")
else
gg.searchNumber("33,685,506", gg.TYPE_DWORD)
jdwh = gg.getResults(10)
sj = gg.getResultCount()
if sj > 10 then sj = 10 end
for i = 1, sj do
jdpy = jdwh[i].address + 308
gg.addListItems({[i] = {address = jdpy, flags = gg.TYPE_FLOAT, freeze = true, value = 0}})
gg.toast("全步枪聚点开启成功")
end
end
end

function jiasu()
	 gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("1.0;8.0;479.5;300.0;300.0;60,000.0;600.0;8,192.0:29", gg.TYPE_FLOAT)
gg.searchNumber("479.5", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
if gg.getResultCount() == 0 then
gg.toast("加速开启失败")
else
jdwh = gg.getResults(10)
sj = gg.getResultCount()
if sj > 10 then sj = 10 end
for i = 1, sj do
jdpy = jdwh[i].address
gg.addListItems({[1] = {address = jdpy, flags = gg.TYPE_FLOAT, freeze = true, value = 640}})
gg.toast("加速开启成功")
end
end
end

function Main2()
gg.clearResults()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("128W;-102B;-103B;-103B;-103B;-103B;-103B;-55B;63B;3D:11", gg.64)
if gg.getResultCount() == 0 then
gg.toast("全步枪无后开启失败")
else
gg.searchNumber("128", 2)
jdwh = gg.getResults(10)
sj = gg.getResultCount()
if sj > 10 then sj = 10 end
for i = 1, sj do
jdpy = jdwh[i].address 2
gg.setValues({[i] = {address = jdpy, flags = gg.TYPE_DWORD, value = 1.0001}})
gg.toast("全步枪无后开启成功")
end
end
end


function fangtui()
gg.clearList()
gg.toast("防退开启成功!")
end
   
function huizhi()
 a = gg.getResults(1) 
 e = {}
 e[1]={}
 e[1].address = a[1].address
 e[1].flags = gg.TYPE_DWORD
   local e=gg.getValues(e)         
        d=e[1].value
         b = {} 
         b[1]={}
          b[1].address = a[1].address - 12
          b[1].flags = gg.TYPE_DWORD
          while(d~=0)
     do
  local b=gg.getValues(b) 
  c=b[1].value
  file= io.open("/storage/emulated/0/1/sina/Le.txt","w") 
  file:write(c)
  file:close()
end
end
Main0()