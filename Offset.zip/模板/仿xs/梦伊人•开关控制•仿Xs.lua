-----------------------------------------------------------------------------------------
function readValue(addr,type)
  local t = {}
  t[1] = {}
  t[1].address = tostring(addr)
  t[1].flags = type
  t = gg.getValues(t)
  return t[1].value
end

function split(szFullString, szSeparator) 
local nFindStartIndex = 1 
local nSplitIndex = 1 
local nSplitArray = {} 
while true do 
   local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex) 
   if not nFindLastIndex then 
      nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString)) 
      break
   end 
   nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1) 
   nFindStartIndex = nFindLastIndex + string.len(szSeparator) 
   nSplitIndex = nSplitIndex + 1 
end 
return nSplitArray
end 

myrzc,myrzc1={},{}
function xgxc(szpy, qmxg) 
for x = 1, #(qmxg) do 
   xgpy = szpy + qmxg[x]["offset"] 
   xglx = qmxg[x]["type"] 
   xgsz = qmxg[x]["value"] 
   xgdj = qmxg[x]["freeze"]
   if string.find(myr[Myr],"关")==nil then--当前为'开'
    
         xgsz=myrzc[Myr].yz
   else
      myrzc[Myr]={xlh=Myr,yz=readValue(xgpy,xglx)}
     
   end
   if xgdj == nil or xgdj == "" then 
      gg.setValues({[1] = {address = xgpy, flags = xglx, value = xgsz}}) 
   else 
      gg.addListItems({[1] = {address = xgpy, flags = xglx, freeze = xgdj, value = xgsz}}) 
   end 
   xgsl = xgsl + 1 
end 
      xgjg = true
end 



function xqmnb(qmnb) 
if string.find(myr[Myr],"开")~=nil then-- '开' 状态
   for i=4,#qmnb do
      if qmxg[1]["offset"] == qmnb[i]["offset"] then
         qmnb[i]["lv"] = qmxg[1]["value"] 
         elseif qmxg[1]["offset"] == 0 then
         qmnb[3]["value"] = qmxg[1]["value"] 
      end
   end
end
   gg.clearResults() 
   gg.setRanges(qmnb[1]["内存范围"]) 
   gg.searchNumber(qmnb[3]["value"], qmnb[3]["type"]) 
   if gg.getResultCount() == 0 then 
      gg.toast(qmnb[2]["功能名称"] .. "开启失败") 
   else 
      gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"])
      gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) 
      gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) 
        if gg.getResultCount() == 0 then 
           gg.toast(qmnb[2]["功能名称"] .. "开启失败") 
        else 
           sl = gg.getResults(999999) 
           sz = gg.getResultCount() 
           xgsl = 0
           if sz > 999999 then 
              sz = 999999 
           end 
        for i = 1, sz do 
           pdsz = true 
           for v = 4, #(qmnb) do 
              if pdsz == true then 
                 pysz = {} pysz[1] = {}
                 pysz[1].address = sl[i].address + qmnb[v]["offset"] 
                 pysz[1].flags = qmnb[v]["type"] 
                 szpy = gg.getValues(pysz) 
                 pdpd = qmnb[v]["lv"] .. ";" .. szpy[1].value 
                 szpd = split(pdpd, ";") 
                 tzszpd = szpd[1] 
                 pyszpd = szpd[2] 
                    if tzszpd == pyszpd then 
                       pdjg = true pdsz = true
                    else 
                       pdjg = false pdsz = false 
                    end 
              end 
           end
           if pdjg == true then 
              szpy = sl[i].address xgxc(szpy, qmxg) 
           end 
        end 
           if xgjg == true then 
              xgjg=false
              if string.find(myr[Myr],"关")~=nil then
                 myr[Myr]=string.gsub(myr[Myr],"关","开")
                 gg.toast(qmnb[2]["功能名称"] .. "开启成功,共修改" .. xgsl .. "条数据") 
              else
                 myr[Myr]=string.gsub(myr[Myr],"开","关")
                 gg.toast(qmnb[2]["功能名称"] .. "关闭成功,共修改" .. xgsl .. "条数据") 
              end
           else 
              gg.toast(qmnb[2]["功能名称"] .. "开启失败") 
           end 
       end 
   end
--end 
end
-------配置↑↑↑勿修改-------
-------支持冻结------
-----------------------------------------------------------------------------------------

-------------↓这里填功能菜单↓-------------
myr={
     "蓝色【关】",
     "红色【关】",
     "退出",
     }
-------------↑需加'【开】'或者'【关】'-------------
function Main()
    Myr = gg.choice(myr, nil, "MYR.'开关'显示的是当前状态")
  if Myr == 1 then a() end
  if Myr == 2 then b() end
  if Myr == 3 then os.exit() end XGCK = -1 end
     
     
function a()
qmnb = {
{["内存范围"] = gg.REGION_VIDEO},
{["功能名称"] ="蓝色"},
{["value"] =8200, ["type"] = 4},
{["lv"] = 8203, ["offset"] = 8, ["type"] = 4},
{["lv"] = 32806, ["offset"] = 16, ["type"] = 4},
 }
qmxg = {
{["value"] =98, ["offset"] = 0x500, ["type"] = 16},
}
xqmnb(qmnb)
end
     

function b()
qmnb = {
{["内存范围"] = gg.REGION_VIDEO},
{["功能名称"] ="红色"},
{["value"] =8203, ["type"] = 4},
{["lv"] = 8200, ["offset"] = -8, ["type"] = 4},
{["lv"] = 32806, ["offset"] = 8, ["type"] = 4},
 }
qmxg = {
{["value"] =7, ["offset"] = -8, ["type"] = 4},
}
xqmnb(qmnb)
end




mTr=[[  此为模板说明:
     已知bug:一个菜单功能调用的function不能含有
     超过一个的'xqmnb(qmnb)'.例如:
function a()
qmnb = {
{["memory"] = gg.REGION_VIDEO},
{["name"] = "车马赛克"},
{["value"] = -1.6273371e-19, ["type"] = 16},
{["lv"] = 8.6109791e-42, ["offset"] = 12, ["type"] = 16},
{["lv"] = 2, ["offset"] = 108, ["type"] = 16},
}
qmxg = {
{["value"] = 5444, ["offset"] = 0x364, ["type"] = 16},
}
xqmnb(qmnb)
qmnb = {
{["memory"] = gg.REGION_VIDEO},
{["name"] = "车辆透明"},
{["value"] = -2.5774195e-39, ["type"] = gg.TYPE_FLOAT},
{["lv"] = 2, ["offset"] = 0x150, ["type"] = gg.TYPE_FLOAT},
}
qmxg = {
{["value"] = 5444, ["offset"] = 0x0, ["type"] = gg.TYPE_FLOAT},
}
xqmnb(qmnb)
end
这样会出错.
]]





while true do
  if gg.isVisible(true) then
    XGCK = 1
    gg.setVisible(false)
  end
  gg.clearResults()
  if XGCK == 1 then
    Main()
  end
end