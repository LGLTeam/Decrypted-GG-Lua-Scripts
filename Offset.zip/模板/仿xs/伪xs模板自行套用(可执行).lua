function split(szFullString, szSeparator)
local nFindStartIndex = 1 
local nSplitIndex = 1 
local nSplitArray = {} while true do 
local 
nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex) 
if not nFindLastIndex then 
nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString)) 
break end 
nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1) 
nFindStartIndex = nFindLastIndex + string.len(szSeparator) 
nSplitIndex = nSplitIndex + 1 end return 
nSplitArray end function 
xgxc(szpy, qmxg) for x = 1, #(qmxg) do 
xgpy = szpy + qmxg[x]["offset"] xglx = qmxg[x]["type"] 
xgsz = qmxg[x]["value"] 
gg.setValues({[1] = {address = xgpy, flags = xglx, value = xgsz}}) 
xgsl = xgsl + 1 end end function 
xqmnb(qmnb) 
gg.clearResults() 
gg.setRanges(qmnb[1]["memory"]) 
gg.searchNumber(qmnb[3]["value"], qmnb[3]["type"]) 
if gg.getResultCount() == 0 then 
gg.toast(qmnb[2]["name"] .. "开启失败")
else 
gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) 
gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) 
gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) 
if gg.getResultCount() == 0 then 
gg.toast(qmnb[2]["name"] .. "开启失败") 
else 
sl = gg.getResults(999999) 
sz = gg.getResultCount() 
xgsl = 0 if sz > 999999 then 
sz = 999999 end for i = 1, sz do 
pdsz = true for v = 4, #(qmnb) do if 
pdsz == true then 
pysz = {} pysz[1] = {} pysz[1].address = sl[i].address + qmnb[v]["offset"] 
pysz[1].flags = qmnb[v]["type"] 
szpy = gg.getValues(pysz) 
pdpd = qmnb[v]["lv"] .. ";" .. szpy[1].value szpd = split(pdpd, ";") 
tzszpd = szpd[1] 
pyszpd = szpd[2] 
if tzszpd == pyszpd then 
pdjg = true pdsz = true else 
pdjg = false pdsz = false end end end 
if pdjg == true then 
szpy = sl[i].address xgxc(szpy, qmxg) 
xgjg = true end end 
if xgjg == true then 
gg.toast(qmnb[2]["name"] .. "开启成功,共修改" .. xgsl .. "条数据") 
else 
gg.toast(qmnb[2]["name"] .. "开启失败") 
end 
end 
end 
end

-----------------------------------------------------------------------------------------

function Main()
  SN = gg.multiChoice({
  "马赛克",
  "透视",
  "绿色",
  "防闪",
  "红色",
  "马赛克修复",
  "透视修复",
  "蓝色",
  "退出脚本"
 }, nil, "这里可以填写你的QQ")
  if SN == nil then
  else
  if SN[1] == true then
    a()
  end
  if SN[2] == true then
   b()
  end
  if SN[3] == true then
   c()
  end
  if SN[4] == true then
   d()
  end
  if SN[5] == true then
   e()
  end
  if SN[6] == true then
   f()
  end
  if SN[7] == true then
   g()
  end
  if SN[8] == true then
   h()
  end
  if SN[9] == true then
   Exit()
  end
end
  XGCK = -1
end


function a()
gg.clearResults()
gg.setRanges(gg.REGION_BAD)
gg.searchNumber("-5.5695588e-40", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
gg.searchNumber("-5.5695588e-40", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(5)
gg.editAll("5444", gg.TYPE_FLOAT)
 gg.toast("马赛克开启成功")
end




function b()
  gg.clearResults()
  gg.setRanges(gg.REGION_BAD)
gg.searchNumber("-2.7610737e-39", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
  gg.searchNumber("-2.7610737e-39", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
  gg.getResults(5)
  gg.editAll("5444", gg.TYPE_FLOAT)
 gg.toast("透视开启成功")
end


function c()
qmnb = {
{["memory"] = 131072},
{["name"] = "2f绿色"},
{["value"] = 2.3709839e21, ["type"] = 16},
{["lv"] = 3.275353e-40, ["offset"] = 4, ["type"] = 16},
{["lv"] = 2.3802073e21, ["offset"] = 8, ["type"] = 16},
{["lv"] = 2, ["offset"] = 24, ["type"] = 16},
}
qmxg = {
{["value"] = 40, ["offset"] = 24, ["type"] = 16},
}
xqmnb(qmnb)
end


function d()
qmnb = {
{["memory"] = 131072},
{["name"] = "防闪第一步"},
{["value"] = 3.0230535e23, ["type"] = 16},
{["lv"] = 2.2963078e-41, ["offset"] = 4, ["type"] = 16},
{["lv"] = 6.50000333786, ["offset"] = 8, ["type"] = 16},
{["lv"] = 8.4077908e-45, ["offset"] = 12, ["type"] = 16},
{["lv"] = 2, ["offset"] = 156, ["type"] = 16},
}
qmxg = {
{["value"] = 9999, ["offset"] = 156, ["type"] = 16},
}
xqmnb(qmnb)
qmnb = {
{["memory"] = 131072},
{["name"] = "山体防闪"},
{["value"] = -6.488152e-40, ["type"] = 16},
{["lv"] = 4.7604163e21, ["offset"] = 4, ["type"] = 16},
{["lv"] = 5.6051939e-45, ["offset"] = 8, ["type"] = 16},
{["lv"] = 1.1202011e-19, ["offset"] = 12, ["type"] = 16},
{["lv"] = 2, ["offset"] = 144, ["type"] = 16},
}
qmxg = {
{["value"] = 9999, ["offset"] = 144, ["type"] = 16},
}
xqmnb(qmnb)
end



function e()
qmnb = {
{["memory"] = 131072},
{["name"] = "8200红色"},
{["value"] = 1080035341, ["type"] = 4},
{["lv"] = 851974, ["offset"] = 4, ["type"] = 4},
{["lv"] = 1661141005, ["offset"] = 8, ["type"] = 4},
{["lv"] = 8200, ["offset"] = 28, ["type"] = 4},
}
qmxg = {
{["value"] = 7, ["offset"] = 28, ["type"] = 4},
}
xqmnb(qmnb)
end



function f()
  gg.clearResults()
  gg.setRanges(gg.REGION_BAD)
gg.searchNumber("5444", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
  gg.searchNumber("5444", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
  gg.getResults(1)
  gg.editAll("-5.5695588e-40", gg.TYPE_FLOAT)
 gg.toast("马赛克修复")
 end



function g()
gg.clearResults()
gg.setRanges(gg.REGION_BAD)
gg.searchNumber("5444", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
gg.searchNumber("5444", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)
gg.getResults(1)
gg.editAll("-2.7610737e-39", gg.TYPE_FLOAT)
 gg.toast("透视修复")
end



function h()
qmnb = {
{["memory"] = 131072},
{["name"] = "蓝色"},
{["value"] = 3.62951922417, ["type"] = 16},
{["lv"] = 1.1490647e-41, ["offset"] = 4, ["type"] = 16},
{["lv"] = 45259, ["offset"] = 8, ["type"] = 16},
}
qmxg = {
{["value"] = 6, ["offset"] = 8, ["type"] = 16},
}
xqmnb(qmnb)
end



function Exit()
print("这里是退出脚本后的提示文字")
os.exit()
end
cs = "这里可以改成你的QQ"



while true do
  if gg.isVisible(true) then
    XGCK = 1
    gg.setVisible(false)
  end
  gg.clearResults()
  if XGCK == 1 then
    Main()
  end
end









