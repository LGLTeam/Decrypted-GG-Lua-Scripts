function split(szFullString, szSeparator)
local nFindStartIndex = 1 
local nSplitIndex = 1 
local nSplitArray = {} while true do 
local 
nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex) 
if not nFindLastIndex then 
nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString)) 
break end 
nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1) 
nFindStartIndex = nFindLastIndex + string.len(szSeparator) 
nSplitIndex = nSplitIndex + 1 end return 
nSplitArray end function 
xgxc(szpy, qmxg) for x = 1, #(qmxg) do 
xgpy = szpy + qmxg[x]["offset"] xglx = qmxg[x]["type"] 
xgsz = qmxg[x]["value"] 
gg.setValues({[1] = {address = xgpy, flags = xglx, value = xgsz}}) 
xgsl = xgsl + 1 end end function 
xqmnb(qmnb) 
gg.clearResults() 
gg.setRanges(qmnb[1]["memory"]) 
gg.searchNumber(qmnb[3]["value"], qmnb[3]["type"]) 
if gg.getResultCount() == 0 then 
gg.toast(qmnb[2]["name"] .. "开启失败")
else 
gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) 
gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) 
gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) 
if gg.getResultCount() == 0 then 
gg.toast(qmnb[2]["name"] .. "开启失败") 
else 
sl = gg.getResults(999999) 
sz = gg.getResultCount() 
xgsl = 0 if sz > 999999 then 
sz = 999999 end for i = 1, sz do 
pdsz = true for v = 4, #(qmnb) do if 
pdsz == true then 
pysz = {} pysz[1] = {} pysz[1].address = sl[i].address + qmnb[v]["offset"] 
pysz[1].flags = qmnb[v]["type"] 
szpy = gg.getValues(pysz) 
pdpd = qmnb[v]["lv"] .. ";" .. szpy[1].value szpd = split(pdpd, ";") 
tzszpd = szpd[1] 
pyszpd = szpd[2] 
if tzszpd == pyszpd then 
pdjg = true pdsz = true else 
pdjg = false pdsz = false end end end 
if pdjg == true then 
szpy = sl[i].address xgxc(szpy, qmxg) 
xgjg = true end end 
if xgjg == true then 
gg.toast(qmnb[2]["name"] .. "开启成功,共修改" .. xgsl .. "条数据") 
else 
gg.toast(qmnb[2]["name"] .. "开启失败") 
end 
end 
end 
end

-----------------------------------------------------------------------------------------

function Main()
  SN = gg.multiChoice({
  "红色",
  "功能名称2",
  "功能名称3",
  "功能名称4",
  "功能名称5",
  "功能名称6",
  "功能名称7",
  "功能名称8",
  "退出脚本"
 }, nil, "这里可以填写你的QQ")
  if SN == nil then
  else
  if SN[1] == true then
    a()
  end
  if SN[2] == true then
   b()
  end
  if SN[3] == true then
   c()
  end
  if SN[4] == true then
   d()
  end
  if SN[5] == true then
   e()
  end
  if SN[6] == true then
   f()
  end
  if SN[7] == true then
   g()
  end
  if SN[8] == true then
   h()
  end
  if SN[9] == true then
   Exit()
  end
end
  XGCK = -1
end


function a()
qmnb = {
{["memory"] = 131072},
{["name"] = "红色"},
{["value"] = 1661501444, ["type"] = 4},
{["lv"] = 851971, ["offset"] = 4, ["type"] = 4},
{["lv"] = 1661501443, ["offset"] = 8, ["type"] = 4},
{["lv"] = 8200, ["offset"] = 60, ["type"] = 4},
}
qmxg = {
{["value"] = 7, ["offset"] = 60, ["type"] = 4},
}
xqmnb(qmnb)
end




function b()
qmnb = {
{["memory"] = 内存范围},
{["name"] = "功能名词"},
{["value"] = 主特征码, ["type"] = 数据类型},
{["lv"] = 1副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
{["lv"] = 2副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
{["lv"] = 3副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
}
qmxg = {
{["value"] = 修改数值, ["offset"] = 偏移量, ["type"] = 数据类型},
}
xqmnb(qmnb)
end


function c()
qmnb = {
{["memory"] = 内存范围},
{["name"] = "功能名词"},
{["value"] = 主特征码, ["type"] = 数据类型},
{["lv"] = 1副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
{["lv"] = 2副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
{["lv"] = 3副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
}
qmxg = {
{["value"] = 修改数值, ["offset"] = 偏移量, ["type"] = 数据类型},
}
xqmnb(qmnb)
end


function d()
qmnb = {
{["memory"] = 内存范围},
{["name"] = "功能名词"},
{["value"] = 主特征码, ["type"] = 数据类型},
{["lv"] = 1副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
{["lv"] = 2副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
{["lv"] = 3副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
}
qmxg = {
{["value"] = 修改数值, ["offset"] = 偏移量, ["type"] = 数据类型},
}
xqmnb(qmnb)
end



function e()
qmnb = {
{["memory"] = 内存范围},
{["name"] = "功能名词"},
{["value"] = 主特征码, ["type"] = 数据类型},
{["lv"] = 1副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
{["lv"] = 2副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
{["lv"] = 3副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
}
qmxg = {
{["value"] = 修改数值, ["offset"] = 偏移量, ["type"] = 数据类型},
}
xqmnb(qmnb)
end



function f()
qmnb = {
{["memory"] = 内存范围},
{["name"] = "功能名词"},
{["value"] = 主特征码, ["type"] = 数据类型},
{["lv"] = 1副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
{["lv"] = 2副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
{["lv"] = 3副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
}
qmxg = {
{["value"] = 修改数值, ["offset"] = 偏移量, ["type"] = 数据类型},
}
xqmnb(qmnb)
 end



function g()
qmnb = {
{["memory"] = 内存范围},
{["name"] = "功能名词"},
{["value"] = 主特征码, ["type"] = 数据类型},
{["lv"] = 1副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
{["lv"] = 2副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
{["lv"] = 3副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
}
qmxg = {
{["value"] = 修改数值, ["offset"] = 偏移量, ["type"] = 数据类型},
}
xqmnb(qmnb)
end



function h()
qmnb = {
{["memory"] = 内存范围},
{["name"] = "功能名词"},
{["value"] = 主特征码, ["type"] = 数据类型},
{["lv"] = 1副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
{["lv"] = 2副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
{["lv"] = 3副特征码, ["offset"] = 偏移量, ["type"] = 数据类型},
}
qmxg = {
{["value"] = 修改数值, ["offset"] = 偏移量, ["type"] = 数据类型},
}
xqmnb(qmnb)
end



function Exit()
print("这里是退出脚本后的提示文字")
os.exit()
end
cs = "这里可以改成你的QQ"



while true do
  if gg.isVisible(true) then
    XGCK = 1
    gg.setVisible(false)
  end
  gg.clearResults()
  if XGCK == 1 then
    Main()
  end
end









