
搜索数值=你特征码
改善数值=你要改那个数值的值(代码)
修改数值=你要把你改善数值的值改为你想要的数值
假如
你要将你的代码改成脚本 2是你要改的数值 要改为10
假如已知精确联合特征码 2;3;4;5 
改善数值2
修改10
gg.clearResults()--这个是开始执行并清除搜索
gg.setRanges(gg.REGION_BAD)--BAD是内存范围 有需要请自行修改
gg.searchNumber("2;3;4;5", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)--seaechNumber是搜索数值 2;3;4;5是我们已知的联合精确搜索特征码 FLOAT是我们所选的搜索数值类型 有需要请自行修改
gg.searchNumber("2", gg.TYPE_FLOAT, false, gg.SIGN_EQUAL, 0, -1)--这里是改善数值 将不要精确特征码数值过滤 只选取2 FLOAT为数据类型 有需要请自行修改
gg.getResults(1)--getResults为你要修改多少个数值 写1就是修改一个 写100就是修改一百个 当然前提是要有这么多个数值才能修改
gg.editAll("10", gg.TYPE_FLOAT)--修改为的数值 我们这里选取2改10。有需要可自行修改 FLOAT为类型 有需要自行修改
 gg.toast("功能开启成功")--这只是一段提示 可删除 有需要括号内自行修改

模板链接https://www.lanzous.com/i64sngh


①gg.setRanges(gg.REGION_VIDEO) 相当于gg.setRanges(1048576) 
②gg.TYPE_DWORD相当于4,  gg.TYPE_FLOAT相当于16

--------内存范围---------↓↓↓
	['REGION_ANONYMOUS'] = 32,
	['REGION_ASHMEM'] = 524288,
	['REGION_BAD'] = 131072,
	['REGION_CODE_APP'] = 16384,
	['REGION_CODE_SYS'] = 32768,
	['REGION_C_ALLOC'] = 4,
	['REGION_C_BSS'] = 16,
	['REGION_C_DATA'] = 8,
	['REGION_C_HEAP'] = 1,
	['REGION_JAVA'] = 65536,
	['REGION_JAVA_HEAP'] = 2,
	['REGION_OTHER'] = -2080896,
	['REGION_PPSSPP'] = 262144,
	['REGION_STACK'] = 64,
	['REGION_VIDEO'] = 1048576,

--------数据类型---------↓↓↓
	['TYPE_AUTO'] = 127,
	['TYPE_BYTE'] = 1,
	['TYPE_DOUBLE'] = 64,
	['TYPE_DWORD'] = 4,
	['TYPE_FLOAT'] = 16,
	['TYPE_QWORD'] = 32,
	['TYPE_WORD'] = 2,
	['TYPE_XOR'] = 8,

