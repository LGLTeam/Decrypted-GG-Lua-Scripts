gg.addListItems() --添加项目到列表中
gg.alert() --弹窗 用法在()添加你想要的字
gg. toast()--提示框 用法在()添加你想要的字
gg.clearList() --清除保存列表 一般不怎么用
gg.clearResults() --清除我们搜索结果 一般在功能内第一行可见
gg.copyText() --将文本复制到剪贴板 用法 在()里面添加你想要别人复制的字
gg.copyMemory() --复制数据、内存 一般来说不怎么用
gg.getResults()--修改多少个数值 用法在()内添加数字为修改多少个数值
gg.editAll() --编辑所有 一般和gg.getResults()一起用 用法在()添加你要修改为什么都数值
gg.setRanges()--获取内存 用法在()填写你要获取的内存
gg.processPause() --暂停进程
gg.processResume()--恢复进程
gg.processToggleo() --切换进程
gg.processKill()--结束进程
gg.removeListitems() --从保存的列表中删除项目
gg.removeResults() --移除找到列表中的结果
gg.saveList() --保存到列表
gg.searchAddress() --搜索地址
gg.getValues() --获取值
gg.getValuesRange() --获取值的范围
FREEZE_ IN _RANGE --冻结在这个范围里
FREEZE_ MAY_ _DECREASE --冻结可以减少的值
FREEZE_ MAY INCREASE --冻结可以增加的值
gg.refineAddress()--gg.refineAddress("蒙版", -1, 类型, gg.SIGN_EQUAL, 0, -1)--蒙版改善
gg.searchNumber()--gg.searchNumber("数值", 类型,false,gg.SIGN_EQUAL,0, -1)--指定数值搜索 可用于联合搜索与数值改善
gg.multiChoice({--多选
gg.choice({--单选
时间公告
  }, nil, "youker男神提醒您\n"..os.date(":现在的时间是%Y年-%m月-%d日 %H时:%M分:%S秒"))--上面的字 公告
gg.alert(os.date("youker男神提醒您:当前开启功能时间为%Y年-%m月-%d日 %H时:%M分:%S秒⚡"))--弹窗
gg.toast(os.date("⚡当前开启功能完成时间为%Y年-%m月-%d日 %H时:%M分:%S秒⚡"))--提示
print("youker男神提醒您"..os.date(":现在的时间是%Y年-%m月-%d日 %H时:%M分:%S秒"))--退出脚本的字
GG类型与范围
①gg.setRanges(gg.REGION_VIDEO) 相当于gg.setRanges(1048576) 
②gg.TYPE_DWORD相当于4,  gg.TYPE_FLOAT相当于16

--------内存范围---------↓↓↓
	['REGION_ANONYMOUS'] = 32,--A内存
	['REGION_ASHMEM'] = 524288,--As内存
	['REGION_BAD'] = 131072,--B内存
	['REGION_CODE_APP'] = 16384,--Xa内存
	['REGION_CODE_SYS'] = 32768,--Xs内存
	['REGION_C_ALLOC'] = 4,--Ca内存
	['REGION_C_BSS'] = 16,--Cb内存
	['REGION_C_DATA'] = 8,--Cd内存
	['REGION_C_HEAP'] = 1,--Ch内存
	['REGION_JAVA'] = 65536,--J内存
	['REGION_JAVA_HEAP'] = 2,--Jh内存
	['REGION_OTHER'] = -2080896,--O内存
	['REGION_PPSSPP'] = 262144,--Ps内存
	['REGION_STACK'] = 64,--S内存
	['REGION_VIDEO'] = 1048576,--V内存

--------数据类型---------↓↓↓
	['TYPE_AUTO'] = 127,--A类型
	['TYPE_BYTE'] = 1,--B类型
	['TYPE_DOUBLE'] = 64,--E类型
	['TYPE_DWORD'] = 4,--D类型
	['TYPE_FLOAT'] = 16,--F类型
	['TYPE_QWORD'] = 32,--Q类型
	['TYPE_WORD'] = 2,--W类型
	['TYPE_XOR'] = 8,--X类型
	
	由youker_男神挑选并且编写 函数来自官网 