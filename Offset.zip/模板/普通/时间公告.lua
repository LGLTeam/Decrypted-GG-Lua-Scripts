function Main()
  SN = gg.multiChoice({
    "845透视",
    "退出脚本",
  }, nil, "youker男神提醒您"..os.date(":现在的时间是%Y年-%m月-%d日 %H时:%M分:%S秒"))--公告
  if SN == nil then
  else
  if SN[1] == true then
   a()
  end
  if SN[2] == true then
    Exit()
  end
end
  XGCK = -1
end



function a()
gg.alert(os.date("youker男神提醒您:当前开启功能时间为%Y年-%m月-%d日 %H时:%M分:%S秒⚡"))
gg.clearResults()
gg.setRanges(gg.REGION_BAD)
gg.searchNumber("搜索数值", gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0, -1)
gg.searchNumber("改善数值", gg.TYPE_FLOAT,false,gg.SIGN_EQUAL,0,-1)
gg.getResults(10)
gg.editAll("修改数值",gg.TYPE_FLOAT)
gg.toast(os.date("⚡当前开启功能完成时间为%Y年-%m月-%d日 %H时:%M分:%S秒⚡"))
end



function Exit()
   print("youker男神提醒您"..os.date(":现在的时间是%Y年-%m月-%d日 %H时:%M分:%S秒"))
  os.exit()
end



cs = "这里可以改成你的QQ"
while true do
  if gg.isVisible(true) then
    XGCK = 1
    gg.setVisible(false)
  end
  gg.clearResults()
  if XGCK == 1 then
    Main()
  end
end
