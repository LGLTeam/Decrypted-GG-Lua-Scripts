--Le编写,非4代 8200定位
--模板不是成品 没有填写配置别问为什么执行不了
--youker_男神群:947838373
--le群:770868115
function split0(szFullString, szSeparator) local nFindStartIndex = 1 local nSplitIndex = 1 local nSplitArray = {} while true do local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex) if not nFindLastIndex then nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString)) break end nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1) nFindStartIndex = nFindLastIndex + string.len(szSeparator) nSplitIndex = nSplitIndex + 1 end return nSplitArray end function xgxc0(szpy, qmxg) for x = 1, #(qmxg) do xgpy = szpy + qmxg[x]["offset"] xglx = qmxg[x]["type"] xgsz = qmxg[x]["value"] mskyz=readValue(xgpy,xglx)      table.insert(ad,{address = xgpy,flags=xglx, freeze = false}) xgsl = xgsl + 1 end end function xqmnb0(qmnb) gg.clearResults() gg.setRanges(qmnb[1]["memory"]) gg.searchNumber(qmnb[3]["value"], qmnb[3]["type"]) if gg.getResultCount() == 0 then gg.toast(qmnb[2]["name"] .. "开启失败") else gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) if gg.getResultCount() == 0 then gg.toast(qmnb[2]["name"] .. "开启失败") else sl = gg.getResults(999999) sz = gg.getResultCount() xgsl = 0 if sz > 999999 then sz = 999999 end for i = 1, sz do pdsz = true for v = 4, #(qmnb) do if pdsz == true then pysz = {} pysz[1] = {} pysz[1].address = sl[i].address + qmnb[v]["offset"] pysz[1].flags = qmnb[v]["type"] szpy = gg.getValues(pysz) pdpd = qmnb[v]["lv"] .. ";" .. szpy[1].value szpd = split0(pdpd, ";") tzszpd = szpd[1] pyszpd = szpd[2] if tzszpd == pyszpd then pdjg = true pdsz = true else pdjg = false pdsz = false end end end if pdjg == true then szpy = sl[i].address xgxc0(szpy, qmxg) xgjg = true end end if xgjg == true then gg.toast(qmnb[2]["name"] .. "捕获成功,共" .. xgsl .. "条数据") mskxgz=qmxg[1]["value"] msklx=qmxg[1]["type"] else gg.toast(qmnb[2]["name"] .. "开启失败") end end end end
function split1(szFullString, szSeparator) local nFindStartIndex = 1 local nSplitIndex = 1 local nSplitArray = {} while true do local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex) if not nFindLastIndex then nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString)) break end nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1) nFindStartIndex = nFindLastIndex + string.len(szSeparator) nSplitIndex = nSplitIndex + 1 end return nSplitArray end 
function xgxc1(szpy, qmxg) for x = 1, #(qmxg) do xgpy = szpy + qmxg[x]["offset"] xglx = qmxg[x]["type"] xgsz = qmxg[x]["value"] tmyz=readValue(xgpy,xglx) table.insert(af,{address = xgpy, flags = xglx }) xgsl = xgsl + 1 end end 
function xqmnb1(qmnb) gg.clearResults() gg.setRanges(qmnb[1]["memory"]) gg.searchNumber(qmnb[3]["value"], qmnb[3]["type"]) if gg.getResultCount() == 0 then gg.toast(qmnb[2]["name"] .. "开启失败") else gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) if gg.getResultCount() == 0 then gg.toast(qmnb[2]["name"] .. "开启失败") else sl = gg.getResults(999999) sz = gg.getResultCount() xgsl = 0 if sz > 999999 then sz = 999999 end for i = 1, sz do pdsz = true for v = 4, #(qmnb) do if pdsz == true then pysz = {} pysz[1] = {} pysz[1].address = sl[i].address + qmnb[v]["offset"] pysz[1].flags = qmnb[v]["type"] szpy = gg.getValues(pysz) pdpd = qmnb[v]["lv"] .. ";" .. szpy[1].value szpd = split1(pdpd, ";") tzszpd = szpd[1] pyszpd = szpd[2] if tzszpd == pyszpd then pdjg = true pdsz = true else pdjg = false pdsz = false end end end if pdjg == true then szpy = sl[i].address xgxc1(szpy, qmxg) xgjg = true end end if xgjg == true then gg.toast(qmnb[2]["name"] .. "捕获成功,共" .. xgsl .. "条数据") tmxgz=qmxg[1]["value"] tmlx=qmxg[1]["type"] else gg.toast(qmnb[2]["name"] .. "开启失败") end end end end
function split(szFullString, szSeparator) local nFindStartIndex = 1 local nSplitIndex = 1 local nSplitArray = {} while true do local nFindLastIndex = string.find(szFullString, szSeparator, nFindStartIndex) if not nFindLastIndex then nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, string.len(szFullString)) break end nSplitArray[nSplitIndex] = string.sub(szFullString, nFindStartIndex, nFindLastIndex - 1) nFindStartIndex = nFindLastIndex + string.len(szSeparator) nSplitIndex = nSplitIndex + 1 end return nSplitArray end function xgxc(szpy, qmxg) for x = 1, #(qmxg) do xgpy = szpy + qmxg[x]["offset"] xglx = qmxg[x]["type"] xgsz = qmxg[x]["value"] gg.setValues({[1] = {address = xgpy, flags = xglx, value = xgsz}}) xgsl = xgsl + 1 end end function xqmnb(qmnb) gg.clearResults() gg.setRanges(qmnb[1]["memory"]) gg.searchNumber(qmnb[3]["value"], qmnb[3]["type"]) if gg.getResultCount() == 0 then gg.toast(qmnb[2]["name"] .. "开启失败") else gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) gg.refineNumber(qmnb[3]["value"], qmnb[3]["type"]) if gg.getResultCount() == 0 then gg.toast(qmnb[2]["name"] .. "开启失败") else sl = gg.getResults(999999) sz = gg.getResultCount() xgsl = 0 if sz > 999999 then sz = 999999 end for i = 1, sz do pdsz = true for v = 4, #(qmnb) do if pdsz == true then pysz = {} pysz[1] = {} pysz[1].address = sl[i].address + qmnb[v]["offset"] pysz[1].flags = qmnb[v]["type"] szpy = gg.getValues(pysz) pdpd = qmnb[v]["lv"] .. ";" .. szpy[1].value szpd = split(pdpd, ";") tzszpd = szpd[1] pyszpd = szpd[2] if tzszpd == pyszpd then pdjg = true pdsz = true else pdjg = false pdsz = false end end end if pdjg == true then szpy = sl[i].address xgxc(szpy, qmxg) xgjg = true end end if xgjg == true then gg.toast(qmnb[2]["name"] .. "开启成功,共修改" .. xgsl .. "条数据") else gg.toast(qmnb[2]["name"] .. "开启失败") end end end end
function readValue(addr,type) local t = {}  t[1] = {}  t[1].address = addr t[1].flags = type t = gg.getValues(t) return tostring(t[1].value) end
--------------------↓↓马赛克配置区↓↓--------------------
function rmsk()
qmnb = {
{["memory"] = gg.REGION_VIDEO},
{["name"] = "人物马赛克"},
{["value"] = 2.25048828125, ["type"] = gg.TYPE_FLOAT},
{["lv"] = 135200, ["offset"] = 4, ["type"] = 4},
}
qmxg = {
{["value"] = 5444, ["offset"] = 100, ["type"] = gg.TYPE_FLOAT},
}
xqmnb0(qmnb) 
end
--------------------↑↑马赛克配置区↑↑--------------------


--------------------↓↓透明配置区↓↓------------------------
function rtm()
qmnb = {
{["memory"] = gg.REGION_VIDEO},
{["name"] = "人物透明"},
{["value"] = 1669693444, ["type"] = 4},
{["lv"] = 281559044, ["offset"] = -4, ["type"] = 4},
}
qmxg = {
{["value"] = 5444, ["offset"] = -156, ["type"] = gg.TYPE_FLOAT},
}
xqmnb1(qmnb)
end
--------------------↑↑透明配置区↑↑------------------------

--------------------↓↓上色配置区↓↓------------------------
function ss8200()
gg.clearResults()
gg.setRanges(gg.REGION_VIDEO)
gg.searchNumber("8200上色特征码",4) --8200上色改善出来必须只有1个值 后面的4是类型
gg.refineNumber("8200",4)--改善
ae=gg.getResults(1) --用变量'ah'储存搜索到的结果
gg.toast("上色添加完成!")
end
--------------------↑↑透明配置区↑↑------------------------

function Main()
Le = gg.choice({
     "透视",--835可用
	 "上色",--自己填写
	 "功能三",--需要自己写
	 "退出脚本",
}, nil, "这里是公告")

if Le==1 then csh() end
if Le==2 then A() end
if Le==3 then B() end
--喜欢的话自己加几个列表
if Le==4 then Exit() end
 XGCK = -1
end

function csh()--不可修改此行
ad,af,Lemsktb,Letmtb={},{},{},{}
rmsk()-- 返回ad表 马赛克修改值:mskxgz  马赛克类型:msklx
gg.addListItems(ad) 
rtm()-- 返回af表
gg.addListItems(af)
ss8200()-- 返回ae表
gg.addListItems(ae)
for i=1,#ad do
   Lemsktb[i] = math.abs(ad[i].address-ae[1].address)
end
min=99999999
for i=1,#ad do
   if Lemsktb[i] < min then
      min = Lemsktb[i]
      mskdz = ad[i]
   end
end
for i=1,#af do
   Letmtb[i] = math.abs(af[i].address-ae[1].address)
end
min=99999999
for i=1,#af do
   if Letmtb[i] < min then
      min = Letmtb[i]
      tmdz = af[i]
   end
end
gg.setValues({[1]={address=mskdz.address,flags=msklx,value=mskxgz}})
gg.setValues({[1]={address=tmdz.address,flags=tmlx,value=tmxgz}})
end
function A()    --自己放对应代码  示例↓也可放普通GG写法
qmnb = {
{["memory"] = 1048576},
{["name"] = "荧光蓝"},
{["value"] = 8200, ["type"] = 4},
{["lv"] = -2128609267, ["offset"] = -12, ["type"] = 4},
{["lv"] = 135390, ["offset"] = -8, ["type"] = 4},
{["lv"] = 1081081858, ["offset"] = -4, ["type"] = 4},
{["lv"] = 1194344462, ["offset"] = 4, ["type"] = 4},
{["lv"] = 8201, ["offset"] = 8, ["type"] = 4},
{["lv"] = 27, ["offset"] = 80, ["type"] = 4},
}
qmxg = {
{["value"] = 23, ["offset"] = 80, ["type"] = 4},

}
xqmnb(qmnb)
end
function B()
end
function Exit()
   print("退出脚本后显示的字")
  os.exit()
end

while true do
  if gg.isVisible(true) then
    XGCK = 1
    gg.setVisible(false)
  end
  if XGCK == 1 then
    Main()
  end
 end