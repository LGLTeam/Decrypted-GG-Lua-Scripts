function readValue(addr)
  local t = {}
  t[1] = {}
  t[1].address = tonumber(addr)
  t[1].flags = 4
  t = gg.getValues(t)
  return t[1].value
end
--用于仿Xs.主特征码

Le=gg.prompt({'地址','偏移范围(4的倍数)','内存范围'},{[1]="",[2]="20",[3]="1048576"},{[1]='text', [2]='text', [3]='text'})
if Le==nil then else Pyfw=Le[2]
gg.clearResults()
gg.setRanges(Le[3])
gg.searchAddress(Le[1],0xFFFFFFFF,4)
LeDz1=gg.getResults(1)
i=1 j=Pyfw/4 Le1={} py1={} Sz1={} Szsl={} Le3={} Sjlx=4
while j~=0 do
Sz1[i]=readValue(LeDz1[1].address-4*j,Sjlx)
gg.setRanges(Le[3])
gg.clearResults()
gg.searchNumber(Sz1[i],Sjlx)
Szsl[i]=gg.getResultCount()
Le1[i]=string.format("%#x",LeDz1[1].address-4*j).."       "..Szsl[i].."         -"..4*j
j=j-1 i=i+1
end
j=#Le1 i=0
while i*4~=Pyfw+4 do
Sz1[i+j+1]=readValue(LeDz1[1].address+4*i,Sjlx)
gg.setRanges(Le[3])
gg.clearResults()
gg.searchNumber(Sz1[i+j+1],Sjlx)
Szsl[i+j+1]=gg.getResultCount()
Le1[i+j+1]=string.format("%#x",LeDz1[1].address+4*i).."       "..Szsl[i+j+1].."         "..4*i
i=i+1
end

LLe=gg.choice(Le1,nil,"地址              搜索数量          偏移")
if LLe<=#Le1 then gg.copyText(Sz1[LLe]) end
end